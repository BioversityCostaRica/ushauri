-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: ushauri
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advgroup`
--

DROP TABLE IF EXISTS `advgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advgroup` (
  `group_id` varchar(12) NOT NULL,
  `group_name` varchar(120) DEFAULT NULL,
  `group_ward` varchar(120) DEFAULT NULL,
  `group_lat` varchar(80) DEFAULT NULL,
  `group_long` varchar(180) DEFAULT NULL,
  `group_elev` decimal(11,3) DEFAULT NULL,
  `county_id` varchar(12) NOT NULL,
  `subcounty_id` varchar(12) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `fk_advgroup_subcounty1_idx` (`county_id`,`subcounty_id`),
  CONSTRAINT `fk_advgroup_county_id_subcounty` FOREIGN KEY (`county_id`, `subcounty_id`) REFERENCES `subcounty` (`county_id`, `subcounty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advgroup`
--

LOCK TABLES `advgroup` WRITE;
/*!40000 ALTER TABLE `advgroup` DISABLE KEYS */;
INSERT INTO `advgroup` VALUES ('eb3f40b10ca4','Makindu group','Makindu','-2.275','37.82',1070.000,'27db4bc1b1aa','17447076fba0');
/*!40000 ALTER TABLE `advgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('e5c7080dd9e0');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `group_id` varchar(12) NOT NULL,
  `answer_id` varchar(12) NOT NULL,
  `user_id` varchar(120) NOT NULL,
  `answer_text` text,
  `answer_votes` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`answer_id`),
  KEY `ix_answer_group_id` (`group_id`),
  KEY `ix_answer_user_id` (`user_id`),
  CONSTRAINT `fk_answer_group_id_advgroup` FOREIGN KEY (`group_id`) REFERENCES `advgroup` (`group_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_answer_user_id_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answeraudio`
--

DROP TABLE IF EXISTS `answeraudio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answeraudio` (
  `group_id` varchar(12) NOT NULL,
  `answer_id` varchar(12) NOT NULL,
  `audio_id` varchar(80) NOT NULL,
  PRIMARY KEY (`group_id`,`answer_id`,`audio_id`),
  KEY `ix_answeraudio_audio_id` (`audio_id`),
  CONSTRAINT `fk_answeraudio_audio_id_audio` FOREIGN KEY (`audio_id`) REFERENCES `audio` (`audio_id`),
  CONSTRAINT `fk_answeraudio_group_id_answer` FOREIGN KEY (`group_id`, `answer_id`) REFERENCES `answer` (`group_id`, `answer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answeraudio`
--

LOCK TABLES `answeraudio` WRITE;
/*!40000 ALTER TABLE `answeraudio` DISABLE KEYS */;
/*!40000 ALTER TABLE `answeraudio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audio`
--

DROP TABLE IF EXISTS `audio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audio` (
  `audio_id` varchar(80) NOT NULL,
  `audio_desc` varchar(120) DEFAULT NULL,
  `audio_file` text,
  `group_id` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`audio_id`),
  KEY `ix_audio_group_id` (`group_id`),
  CONSTRAINT `fk_audio_group_id_advgroup` FOREIGN KEY (`group_id`) REFERENCES `advgroup` (`group_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audio`
--

LOCK TABLES `audio` WRITE;
/*!40000 ALTER TABLE `audio` DISABLE KEYS */;
INSERT INTO `audio` VALUES ('019c73e9-a1f1-4ce1-a3b4-49cbcd21118c','English','019c73e9-a1f1-4ce1-a3b4-49cbcd21118c',NULL),('0ad15bac-eb71-43bc-8eb4-fff5235388ac','English','0ad15bac-eb71-43bc-8eb4-fff5235388ac',NULL),('84d6ae35-9222-4bda-a04c-6d7cb893e81e','English','84d6ae35-9222-4bda-a04c-6d7cb893e81e',NULL),('8e5964f8-be65-46ba-afba-d5b865c80e9f','English','8e5964f8-be65-46ba-afba-d5b865c80e9f',NULL),('aa061019-5dc9-44b5-9ff4-21353847fc8f','English','aa061019-5dc9-44b5-9ff4-21353847fc8f',NULL);
/*!40000 ALTER TABLE `audio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `county`
--

DROP TABLE IF EXISTS `county`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `county` (
  `county_id` varchar(12) NOT NULL,
  `county_name` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`county_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `county`
--

LOCK TABLES `county` WRITE;
/*!40000 ALTER TABLE `county` DISABLE KEYS */;
INSERT INTO `county` VALUES ('27db4bc1b1aa','Makueni');
/*!40000 ALTER TABLE `county` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupuser`
--

DROP TABLE IF EXISTS `groupuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupuser` (
  `group_id` varchar(12) NOT NULL,
  `user_id` varchar(120) NOT NULL,
  `access_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `ix_groupuser_user_id` (`user_id`),
  CONSTRAINT `fk_groupuser_group_id_advgroup` FOREIGN KEY (`group_id`) REFERENCES `advgroup` (`group_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_groupuser_user_id_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupuser`
--

LOCK TABLES `groupuser` WRITE;
/*!40000 ALTER TABLE `groupuser` DISABLE KEYS */;
INSERT INTO `groupuser` VALUES ('eb3f40b10ca4','bortiz',1),('eb3f40b10ca4','cquiros',1),('eb3f40b10ca4','jsteinke',1);
/*!40000 ALTER TABLE `groupuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itemaudio`
--

DROP TABLE IF EXISTS `itemaudio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemaudio` (
  `item_id` varchar(12) NOT NULL,
  `language_code` varchar(4) NOT NULL,
  `audio_id` varchar(80) NOT NULL,
  PRIMARY KEY (`item_id`,`language_code`),
  KEY `ix_itemaudio_audio_id` (`audio_id`),
  KEY `ix_itemaudio_language_code` (`language_code`),
  CONSTRAINT `fk_itemaudio_audio_id_audio` FOREIGN KEY (`audio_id`) REFERENCES `audio` (`audio_id`),
  CONSTRAINT `fk_itemaudio_item_id_menuitem` FOREIGN KEY (`item_id`) REFERENCES `menuitem` (`item_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_itemaudio_language_code_language` FOREIGN KEY (`language_code`) REFERENCES `language` (`language_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemaudio`
--

LOCK TABLES `itemaudio` WRITE;
/*!40000 ALTER TABLE `itemaudio` DISABLE KEYS */;
INSERT INTO `itemaudio` VALUES ('21353847fc8f','en','0ad15bac-eb71-43bc-8eb4-fff5235388ac'),('49cbcd21118c','en','84d6ae35-9222-4bda-a04c-6d7cb893e81e'),('fff5235388ac','en','8e5964f8-be65-46ba-afba-d5b865c80e9f'),('6d7cb893e81e','en','aa061019-5dc9-44b5-9ff4-21353847fc8f');
/*!40000 ALTER TABLE `itemaudio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivrlog`
--

DROP TABLE IF EXISTS `ivrlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivrlog` (
  `log_id` varchar(80) NOT NULL,
  `log_dtime` datetime DEFAULT NULL,
  `group_id` varchar(12) NOT NULL,
  `member_id` varchar(45) NOT NULL,
  `item_id` varchar(12) NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `fk_ivrlog_member1_idx` (`group_id`,`member_id`),
  KEY `ix_ivrlog_item_id` (`item_id`),
  CONSTRAINT `fk_ivrlog_group_id_member` FOREIGN KEY (`group_id`, `member_id`) REFERENCES `member` (`group_id`, `member_id`),
  CONSTRAINT `fk_ivrlog_item_id_menuitem` FOREIGN KEY (`item_id`) REFERENCES `menuitem` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivrlog`
--

LOCK TABLES `ivrlog` WRITE;
/*!40000 ALTER TABLE `ivrlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivrlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivrmenu`
--

DROP TABLE IF EXISTS `ivrmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivrmenu` (
  `group_id` varchar(12) NOT NULL,
  `menu_id` varchar(12) NOT NULL,
  `menu_name` varchar(45) DEFAULT NULL,
  `menu_current` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`menu_id`),
  CONSTRAINT `fk_ivrmenu_group_id_advgroup` FOREIGN KEY (`group_id`) REFERENCES `advgroup` (`group_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivrmenu`
--

LOCK TABLES `ivrmenu` WRITE;
/*!40000 ALTER TABLE `ivrmenu` DISABLE KEYS */;
INSERT INTO `ivrmenu` VALUES ('eb3f40b10ca4','bbae1108e4a3','Example of menu',1);
/*!40000 ALTER TABLE `ivrmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `language_code` varchar(4) NOT NULL,
  `language_name` varchar(120) DEFAULT NULL,
  `audio_id` varchar(80) NOT NULL,
  PRIMARY KEY (`language_code`),
  KEY `ix_language_audio_id` (`audio_id`),
  CONSTRAINT `fk_language_audio_id_audio` FOREIGN KEY (`audio_id`) REFERENCES `audio` (`audio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES ('en','English','019c73e9-a1f1-4ce1-a3b4-49cbcd21118c');
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `group_id` varchar(12) NOT NULL,
  `member_id` varchar(45) NOT NULL,
  `member_name` varchar(120) DEFAULT NULL,
  `member_tele` varchar(45) DEFAULT NULL,
  `member_gender` int(11) DEFAULT NULL,
  `member_village` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`member_id`),
  CONSTRAINT `fk_member_group_id_advgroup` FOREIGN KEY (`group_id`) REFERENCES `advgroup` (`group_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menuitem`
--

DROP TABLE IF EXISTS `menuitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menuitem` (
  `item_id` varchar(12) NOT NULL,
  `item_type` int(11) DEFAULT NULL,
  `item_desc` text,
  `item_pos` int(11) DEFAULT NULL,
  `group_id` varchar(12) NOT NULL,
  `menu_id` varchar(12) NOT NULL,
  `next_item` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `fk_menuitem_ivrmenu1_idx` (`group_id`,`menu_id`),
  KEY `ix_menuitem_next_item` (`next_item`),
  CONSTRAINT `fk_menuitem_group_id_ivrmenu` FOREIGN KEY (`group_id`, `menu_id`) REFERENCES `ivrmenu` (`group_id`, `menu_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_menuitem_next_item_menuitem` FOREIGN KEY (`next_item`) REFERENCES `menuitem` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menuitem`
--

LOCK TABLES `menuitem` WRITE;
/*!40000 ALTER TABLE `menuitem` DISABLE KEYS */;
INSERT INTO `menuitem` VALUES ('21353847fc8f',3,'Livestock content Berta',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('2dd0bf165f8d',1,'Crops menu. To listen to Jacob about mulching press 1. To listen to Jonathan about cover crops press 2. To go back to the topic menu press 0.',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('49cbcd21118c',3,'Crop content Jacob',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('50e99c583aaa',1,'Livestock menu. To listen to Berta about milking health practices press 1. To listen to Carlos about artificial insemination press 2. To go back to the topic menu press 0.',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('603b7e3f652f',1,'Podcast menu. For podcasts on crops press 1. For podcasts on livestock press 2. To go back to the main menu press 0',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('6d7cb893e81e',3,'Crop content Jonathan',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('860d247f4bc7',1,'Welcome to the Agricultural Podcast service. To listen to a podcast press 1. To request for new content press 2',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('f5ef44c3bfc9',2,'Record voice 2',0,'eb3f40b10ca4','bbae1108e4a3',NULL),('fff5235388ac',3,'Livestock content Carlos',0,'eb3f40b10ca4','bbae1108e4a3',NULL);
/*!40000 ALTER TABLE `menuitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menuwelcome`
--

DROP TABLE IF EXISTS `menuwelcome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menuwelcome` (
  `group_id` varchar(12) NOT NULL,
  `menu_id` varchar(12) NOT NULL,
  `language_code` varchar(4) NOT NULL,
  `audio_id` varchar(80) NOT NULL,
  PRIMARY KEY (`group_id`,`menu_id`,`language_code`),
  KEY `ix_menuwelcome_audio_id` (`audio_id`),
  KEY `ix_menuwelcome_language_code` (`language_code`),
  CONSTRAINT `fk_menuwelcome_audio_id_audio` FOREIGN KEY (`audio_id`) REFERENCES `audio` (`audio_id`),
  CONSTRAINT `fk_menuwelcome_group_id_ivrmenu` FOREIGN KEY (`group_id`, `menu_id`) REFERENCES `ivrmenu` (`group_id`, `menu_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_menuwelcome_language_code_language` FOREIGN KEY (`language_code`) REFERENCES `language` (`language_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menuwelcome`
--

LOCK TABLES `menuwelcome` WRITE;
/*!40000 ALTER TABLE `menuwelcome` DISABLE KEYS */;
/*!40000 ALTER TABLE `menuwelcome` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `group_id` varchar(12) NOT NULL,
  `member_id` varchar(45) NOT NULL,
  `question_id` varchar(12) NOT NULL,
  `question_dtime` varchar(45) DEFAULT NULL,
  `question_audiofile` text,
  `question_text` text,
  `question_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`member_id`,`question_id`),
  CONSTRAINT `fk_question_group_id_member` FOREIGN KEY (`group_id`, `member_id`) REFERENCES `member` (`group_id`, `member_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionanswer`
--

DROP TABLE IF EXISTS `questionanswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionanswer` (
  `group_id` varchar(12) NOT NULL,
  `member_id` varchar(45) NOT NULL,
  `question_id` varchar(12) NOT NULL,
  `answer_group` varchar(12) NOT NULL,
  `answer_id` varchar(12) NOT NULL,
  `answer_sent` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`member_id`,`question_id`,`answer_group`,`answer_id`),
  KEY `fk_questionanswer_answer1_idx` (`answer_group`,`answer_id`),
  CONSTRAINT `fk_questionanswer_answer_group_answer` FOREIGN KEY (`answer_group`, `answer_id`) REFERENCES `answer` (`group_id`, `answer_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_questionanswer_group_id_question` FOREIGN KEY (`group_id`, `member_id`, `question_id`) REFERENCES `question` (`group_id`, `member_id`, `question_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionanswer`
--

LOCK TABLES `questionanswer` WRITE;
/*!40000 ALTER TABLE `questionanswer` DISABLE KEYS */;
/*!40000 ALTER TABLE `questionanswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questiontag`
--

DROP TABLE IF EXISTS `questiontag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questiontag` (
  `group_id` varchar(12) NOT NULL,
  `member_id` varchar(45) NOT NULL,
  `question_id` varchar(12) NOT NULL,
  `tag_name` varchar(120) NOT NULL,
  PRIMARY KEY (`group_id`,`member_id`,`question_id`,`tag_name`),
  CONSTRAINT `fk_questiontag_group_id_question` FOREIGN KEY (`group_id`, `member_id`, `question_id`) REFERENCES `question` (`group_id`, `member_id`, `question_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questiontag`
--

LOCK TABLES `questiontag` WRITE;
/*!40000 ALTER TABLE `questiontag` DISABLE KEYS */;
/*!40000 ALTER TABLE `questiontag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `response`
--

DROP TABLE IF EXISTS `response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `response` (
  `item_id` varchar(12) NOT NULL,
  `resp_num` int(11) NOT NULL,
  `target_item` varchar(12) NOT NULL,
  `resp_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_id`,`resp_num`),
  KEY `ix_response_target_item` (`target_item`),
  CONSTRAINT `fk_response_item_id_menuitem` FOREIGN KEY (`item_id`) REFERENCES `menuitem` (`item_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_response_target_item_menuitem` FOREIGN KEY (`target_item`) REFERENCES `menuitem` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response`
--

LOCK TABLES `response` WRITE;
/*!40000 ALTER TABLE `response` DISABLE KEYS */;
INSERT INTO `response` VALUES ('2dd0bf165f8d',0,'603b7e3f652f',1),('2dd0bf165f8d',1,'49cbcd21118c',0),('2dd0bf165f8d',2,'6d7cb893e81e',0),('50e99c583aaa',0,'603b7e3f652f',1),('50e99c583aaa',1,'21353847fc8f',0),('50e99c583aaa',2,'fff5235388ac',0),('603b7e3f652f',0,'860d247f4bc7',1),('603b7e3f652f',1,'2dd0bf165f8d',0),('603b7e3f652f',2,'50e99c583aaa',0),('860d247f4bc7',1,'603b7e3f652f',0),('860d247f4bc7',2,'f5ef44c3bfc9',1);
/*!40000 ALTER TABLE `response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcounty`
--

DROP TABLE IF EXISTS `subcounty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcounty` (
  `county_id` varchar(12) NOT NULL,
  `subcounty_id` varchar(12) NOT NULL,
  `subcounty_name` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`county_id`,`subcounty_id`),
  CONSTRAINT `fk_subcounty_county_id_county` FOREIGN KEY (`county_id`) REFERENCES `county` (`county_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcounty`
--

LOCK TABLES `subcounty` WRITE;
/*!40000 ALTER TABLE `subcounty` DISABLE KEYS */;
INSERT INTO `subcounty` VALUES ('27db4bc1b1aa','17447076fba0','Makindu');
/*!40000 ALTER TABLE `subcounty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` varchar(120) NOT NULL,
  `user_name` varchar(45) DEFAULT NULL,
  `user_pass` varchar(120) DEFAULT NULL,
  `user_active` int(11) DEFAULT NULL,
  `user_admin` int(11) DEFAULT NULL,
  `county_id` varchar(12) DEFAULT NULL,
  `subcounty_id` varchar(12) DEFAULT NULL,
  `user_email` text,
  PRIMARY KEY (`user_id`),
  KEY `fk_user_subcounty1_idx` (`county_id`,`subcounty_id`),
  CONSTRAINT `fk_user_county_id_subcounty` FOREIGN KEY (`county_id`, `subcounty_id`) REFERENCES `subcounty` (`county_id`, `subcounty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('admin',NULL,'pUVZGzJJPhqPzlHb/vqtptztfQ+yu6g5lmzL2da5/8d6Ny4tRmLC31kUUpD08eJg',1,0,NULL,NULL,'c.f.quiros@cgiar.org'),('bortiz','Berta Ortiz','FLiaR0PkmpzUUx9j1lAiBd+7b6iHQaw+YQfVMvjy5KEIQE25J1CGnRWVckZ2iNIX',1,0,'27db4bc1b1aa','17447076fba0','berta.ortizcrespo@gmail.com'),('cquiros','Carlos Quiros','N5AbmbL+evQSzXKdbLrbfYoVDja+OGs/l6gOjmwhLxLRdiJHlLSQRHfIgMtMBp+B',1,0,'27db4bc1b1aa','17447076fba0','cquiros@qlands.com'),('jsteinke','Jonathan Steinke','km2jkAwOOGXZYtNAdHwTvlb/gOZfStY/LCpgBLddIeYd12u8kRl6ms6M35bS1uaW',1,0,'27db4bc1b1aa','17447076fba0','j.steinke@cgiar.org');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-28 15:43:01
